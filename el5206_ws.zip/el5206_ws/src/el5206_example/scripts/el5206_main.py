#!/usr/bin/env python3
"""
This is the main script used for the EL5206 Robotics component. This script is
written Python 3 and defines a EL5206_Robot node for you to program. You will
find notes on how the code works, auxiliary functions and some for you to
program.

Authors: Your dear 2022.Spring.teaching_staff
(Eduardo Jorquera, Ignacio Dassori & Felipe Vergara)
"""
import matplotlib.pyplot as plt
import math
import numpy as np
import rospkg
import rospy
import sys
import tf
import tf2_ros
import time
import yaml

from geometry_msgs.msg import Twist, Pose2D
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan


class EL5206_Robot:
    def __init__(self):
        # Initialize ROS Node
        rospy.init_node('EL5206_Main_Node', anonymous=False)

        # Attributes
        self.robot_frame_id = 'base_footprint'
        self.odom_frame_id = 'odom'
        self.currentScan = None
        self.odom_x = None
        self.odom_y = None
        self.odom_yaw = None
        self.gt_x = None
        self.gt_y = None
        self.gt_yaw = None
        self.odom_lst = []
        self.gt_lst = []
        self.poses_to_save = 300
        self.target_x = None
        self.target_y = None
        self.target_yaw = None
        self.path = rospkg.RosPack().get_path('el5206_example')

        # Extra variable to print odometry
        self.odom_i = 0

        # Subscribers
        rospy.Subscriber("/odom", Odometry, self.odometryCallback)
        rospy.Subscriber("/ground_truth/state", Odometry, self.groundTruthCallback)
        rospy.Subscriber("/scan", LaserScan, self.scanCallback)
        rospy.Subscriber("/target_pose", Pose2D, self.poseCallback)

        # Publishers
        self.vel_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)

        # Timer
        self.update_timer = rospy.Timer(rospy.Duration(1.0), self.timerCallback)

    """
    Callback functions are executed every time a ROS messaage is received by the
    Subscirbers defined in the __init__ method. You have to be careful with 
    these methods, because they are executed several times a second and should 
    be quick enough to finnish before the next message arrives. 

    Be careful with the variables stored in a callback, because these methods 
    can be threaded, they may change some of the variables you are using in the 
    main code.
    """

    def scanCallback(self, msg):
        """
        Receives a LaserScan message and saves it self.currentScan.
        """
        self.currentScan = msg

    def odometryCallback(self, msg):
        """
        Receives an Odometry message. Uses the auxiliary method odom2Coords()
        to get the (x,y,yaw) coordinates and save the in the self.odom_x,
        self.odom_y and self.odom_yaw attributes.
        """
        """
        self.odom_i += 1
        if self.odom_i%30==0:
            # Print one every 30 msgs
            print("This is the Odometry message:")
            print(msg)
        """
        self.odom_x, self.odom_y, self.odom_yaw = self.odom2Coords(msg)

    def groundTruthCallback(self, msg):
        """
        Receives an Odometry message. Uses the auxiliary method odom2Coords()
        to get the (x,y,yaw) coordinates ans saves the in the self.gt_x,
        self.gt_y and self.gt_yaw attributes
        """
        self.gt_x, self.gt_y, self.gt_yaw = self.odom2Coords(msg)

    def poseCallback(self, msg):
        """
        This method is activated whenever a message in the /target_pose topic 
        is published. For the assignments that require a target pose, you can 
        call your assignment functions from here or from the __main__ section
        at the end.
        """
        self.target_x   = msg.x
        self.target_y   = msg.y
        self.target_yaw = msg.theta
        if (self.target_yaw == 1):
        	self.asssignment_2()
        elif (self.target_yaw == 2):
            self.asssignment_2_2()
        elif (self.target_yaw == 3):
            self.asssignment_4()
            
        self.plotOdomVsGroundTruth()
        
    def timerCallback(self, event):
        """
        This timer function will save the odometry and Ground Truth values
        for the position in the self.odom_lst and self.gt_lst so you can
        compare them afterwards. It is updated every 1 second for 300 poses
        (about 5 mins).
        """
        if self.odom_x is not None and self.gt_x is not None and len(self.odom_lst) < self.poses_to_save:
            self.odom_lst.append((self.odom_x, self.odom_y))
            self.gt_lst.append((self.gt_x, self.gt_y))

    """
    Now let's define some auxiliary methods. These are used to solve the 
    problems in the assignments.
    """

    def odom2Coords(self, odom_msg):
        """
        This is an auxiliary method used to get the (x, y, yaw) coordinates from
        an Odometry message. You can use the cmd "$ rostopic echo -n 1 /odom"
        in the terminal to check out the Odometry message attributes.

        Hint: Check the built-in functions in the tf.transformations package to
        see if there is one that handles the euler-quaternion transformation.
        http://docs.ros.org/en/melodic/api/tf/html/python/transformations.html
        """

        pos = odom_msg.pose.pose.position
        x = pos.x
        y = pos.y

        orientation = odom_msg.pose.pose.orientation
        quaternion = np.array([orientation.x, orientation.y,
                               orientation.z, orientation.w])

        yaw = tf.transformations.euler_from_quaternion(quaternion, axes='sxyz')[2]

        return (x, y, yaw)

    def saveLaser(self):
        """
        For the RANSAC experience, it is very common for students to save the
        Laser array and work from home with Jupyter Notebook or Google Colab.
        """
        # Wait for laser to arrive
        while self.currentScan is None:
            pass

        ranges = np.array(self.currentScan.ranges)
        a_min = self.currentScan.angle_min
        a_inc = self.currentScan.angle_increment
        angles = np.array([a_min + i * a_inc for i in range(len(ranges))])

        array_to_save = np.stack([ranges, angles], axis=1)
        with open(self.path + "/results/laser_ranges.npy", "wb") as f:
            np.save(f, array_to_save)
            print("Saved array of shape (%i, %i)" % array_to_save.shape)
            print("Look it up in the %s/results directory" % self.path)

    def plotOdomVsGroundTruth(self):
        """
        Imports a map image and plots the trajectory of the robot according to 
        the Odometry frame and Gazebo's Ground Truth.
        """
        if len(self.odom_lst)>0:
            img = plt.imread(self.path+'/maps/map.pgm')
            print('Image imported')
            # Import map YAML (This is a text file with information about the map)
            with open(self.path+"/maps/map.yaml", 'r') as stream:
                data       = yaml.safe_load(stream)
                origin     = data['origin']
                resolution = data['resolution']
                height     = img.shape[0]
            
            odom_arr = np.array(self.odom_lst)
            gt_arr   = np.array(self.gt_lst)
            
            odom_x_px = ((odom_arr[:,0] - origin[0])/resolution).astype(int)
            odom_y_px = (height-1+ (origin[1]-odom_arr[:,1])/resolution).astype(int)
            gt_x_px = ((gt_arr[:,0] - origin[0])/resolution).astype(int)
            gt_y_px = (height-1+ (origin[1]-gt_arr[:,1])/resolution).astype(int)
            target_x = (self.target_x- origin[0])/resolution
            target_y = height-1 +(origin[1]-self.target_y)/resolution
            
            
            plt.imshow(img,cmap='gray')
            plt.plot(odom_x_px, odom_y_px, color="red", linewidth=1, label='Odometry')
            plt.plot(gt_x_px, gt_y_px, color="blue", linewidth=1, label='Ground Truth')
            plt.plot(target_x, target_y, marker ="o", markersize = "5", markeredgecolor="red", markerfacecolor="green", label = "Target")
            plt.legend()
            plt.grid()
            plt.title('Path planning algorithm')
            plt.axis('off')
            plt.savefig(self.path+'/results/trajectories.png')

    def printOdomvsGroundTruth(self):
        """
        Prints the robot odometry and ground truth position/angle.
        """
        if self.odom_x is not None and self.gt_x is not None:
            print("                  Odometry         -        GroundTruth")
            print("(x,y,yaw):  (%6.2f,%6.2f,%6.2f) - (%6.2f,%6.2f,%6.2f)" % (
            self.odom_x, self.odom_y, self.odom_yaw, self.gt_x, self.gt_y, self.gt_yaw))

    def dance(self, timeout=30):
        """
        Demo function. Moves the robot with the vel_pub Publisher.
        """
        start_time = time.time()
        while time.time() - start_time < timeout and not rospy.is_shutdown():
            # Comparamos los datos de odoemtría

            # Move forward
            twist_msg = Twist()
            twist_msg.linear.x = 0.2
            twist_msg.angular.z = 0.0
            self.vel_pub.publish(twist_msg)
            time.sleep(1)

            # Move backward
            twist_msg = Twist()
            twist_msg.linear.x = -0.2
            twist_msg.angular.z = 0.0
            self.vel_pub.publish(twist_msg)
            time.sleep(1)

            # Turn left
            twist_msg = Twist()
            twist_msg.linear.x = 0.0
            twist_msg.angular.z = 0.2
            self.vel_pub.publish(twist_msg)
            time.sleep(1)

            # Turn right
            twist_msg = Twist()
            twist_msg.linear.x = 0.0
            twist_msg.angular.z = -0.2
            self.vel_pub.publish(twist_msg)
            time.sleep(1)

    def asssignment_1(self, timeout=60):
        # You can use this method to solve the Assignment 1.
        # START: YOUR CODE HERE
        start_time = time.time()
        while time.time() - start_time < timeout and not rospy.is_shutdown():
            self.printOdomvsGroundTruth()
            time.sleep(1)

        self.plotOdomVsGroundTruth()
        # END: YOUR CODE HERE
        pass

    def asssignment_2(self):
        dx = self.target_x - self.odom_x
        dy = self.target_y - self.odom_y
        dtheta = math.atan2(dy, dx) - self.odom_yaw
        print("Final theta: %.5f [rad]" % dtheta)
        
        distance = np.sqrt(dx*dx + dy*dy)
        
		# Stop linear & set angular
        twist_msg = Twist()
        twist_msg.angular.z = 0.2
        twist_msg.linear.x = 0.0
        self.vel_pub.publish(twist_msg)
        print("Time sleep angular movement: %.2f [s]" % abs(dtheta/twist_msg.angular.z))
        time.sleep(abs(dtheta/twist_msg.angular.z))
        
        # Stop Angular & set linear
        twist_msg.angular.z = 0.0
        twist_msg.linear.x  = 0.3
        self.vel_pub.publish(twist_msg)
        print("Time sleep linear movement: %.2f [s]" % abs(distance/twist_msg.linear.x))
        time.sleep(abs(distance/twist_msg.linear.x))
        
        # Stop Linear
        twist_msg.linear.x = 0.0
        self.vel_pub.publish(twist_msg)
        
        print("Final odom position: (%.2f, %.2f)" % (self.odom_x, self.odom_y))
        print("Final truth position: (%.2f, %.2f)" % (self.gt_x, self.gt_y))
        print("Robot has stopped.")
        pass
        
    def asssignment_2_2(self):
        # Second method
        r = rospy.Rate(5)
        Kp = 1
        it = 500
        distance = float('inf')
        while distance > 0.1 and it > 0:
            dx = self.target_x - self.odom_x
            dy = self.target_y - self.odom_y
            dtheta = math.atan2(dy, dx) - self.odom_yaw
            distance = np.sqrt(dx*dx + dy*dy)
            velocidad_angular = Kp*dtheta
            
            twist_msg = Twist()
            twist_msg.angular.z = velocidad_angular
            twist_msg.linear.x = 0.1
            self.vel_pub.publish(twist_msg)
            r.sleep()
            it = it-1
        
        # Stop
        twist_msg.angular.z = 0.0
        twist_msg.linear.x = 0.0
        self.vel_pub.publish(twist_msg)
        print("Final odom position: (%.2f, %.2f)" % (self.odom_x, self.odom_y))
        print("Final truth position: (%.2f, %.2f)" % (self.gt_x, self.gt_y))
        print("Robot has stopped.")
        pass

    def asssignment_3(self):
        # You can use this method to solve the Assignment 3.
        self.saveLaser()
        pass

    def laser_points(self):
        ranges = np.array(self.currentScan.ranges)
        a_min = self.currentScan.angle_min
        a_inc = self.currentScan.angle_increment
        angles = np.array([a_min + i * a_inc for i in range(len(ranges))])
        points = np.vstack((ranges, angles)).T
        return points

    def asssignment_4(self, Katt = 5, Krep = 5/10, Rmax = 0.5, Rmin = 0.1, dt = 0.1, v=0.1, timeout = 200):
        print("Initial odom position: (%.2f, %.2f)" % (self.odom_x, self.odom_y))
        start = time.time()
        stop_msg = Twist()
        stop_msg.linear.x = 0.0
        stop_msg.angular.z = 0.0
        self.vel_pub.publish(stop_msg)
        time.sleep(5*dt)
        P = float('inf')
        R = np.linalg.norm(np.array([self.target_y-self.odom_y,self.target_x-self.odom_x]))
        Rbest = R
        #  and P > 0.1
        while np.linalg.norm(np.array([self.target_y-self.odom_y,self.target_x-self.odom_x])) > Rmin and P > 0.1 and time.time() - start < timeout:
            # Limiting the Attractive Force
            R = np.linalg.norm(np.array([self.target_y - self.odom_y, self.target_x - self.odom_x]))
            if Rbest > R: Rbest = R
            beta = 1 if R < Rmax else Rmax/R
            Xatt = Katt * beta * (self.target_x - self.odom_x)
            Yatt = Katt * beta * (self.target_y - self.odom_y)
                    
            # Repulsion Away from Obstacles
            points = self.laser_points()
            n = len(points) # IMPORTANTE: Considerar los infinitos
            points = points[~np.isinf(points).any(axis=1)]
            F = 0; S = 0
            for d, yaw in points:
                F += 1/(d*d) * np.cos(yaw)
                S += 1/(d*d) * np.sin(yaw)
                
            Xrep = Krep*F*np.cos(self.odom_yaw) - Krep*S*np.sin(self.odom_yaw)
            Yrep = Krep*F*np.sin(self.odom_yaw) + Krep*S*np.cos(self.odom_yaw)
            Xrep /= n
            Yrep /= n
            
            # Path planning
            Px = Xatt - Xrep
            Py = Yatt - Yrep
            P  = np.sqrt(Px*Px + Py*Py)
            Ptheta = math.atan2(Py, Px)
            # Action of motion
            while (np.abs(Ptheta - self.odom_yaw) > 0.1):
                print("Dif Angle: %.2f" % (Ptheta - self.odom_yaw))
                print("Angle: %.2f" % self.odom_yaw)
                twist_msg = Twist()
                twist_msg.angular.z = v*np.sign(Ptheta - self.odom_yaw) # Velocidad angular
                twist_msg.linear.x = 0
                self.vel_pub.publish(twist_msg)
                time.sleep(dt)
            
            twist_msg.angular.z = 0
            twist_msg.linear.x = P*0.3 # Velocidad lineal
            self.vel_pub.publish(twist_msg)
            time.sleep(0.2)
            # Detenciòn para evitar problemas de inercia
            self.vel_pub.publish(stop_msg)
            time.sleep(dt)
            
            print("Linear & Angular velocity: (%.2f, %.2f)" % (P*dt, Ptheta*dt))
            print("Distance: %.2f" % R)
        
        self.vel_pub.publish(stop_msg)
        time.sleep(dt)
        if time.time() - start > timeout: print("Time out.")
        print("Best distance: %.2f" % Rbest)
        print("Final odom position: (%.2f, %.2f)" % (self.odom_x, self.odom_y))
        print("Final truth position: (%.2f, %.2f)" % (self.gt_x, self.gt_y))
        print("Robot has stopped.")
        
        pass

    def stop(self):
        twist_msg = Twist()
        twist_msg.angular.z = 0
        twist_msg.linear.x = 0
        self.vel_pub.publish(twist_msg)
        pass

if __name__ == '__main__':
    node = EL5206_Robot()
    print("EL5206 Node started!")

    try:
        # Demo function
        node.stop()
        rospy.spin()

    except rospy.ROSInterruptException:
        rospy.logerr("ROS Interrupt Exception! Just ignore the exception!")
        

    except rospy.ROSInterruptException:
        rospy.logerr("ROS Interrupt Exception! Just ignore the exception!")
