# el5206_ws
Workspace for EL5206 - FCFM

# Instrucciones

Este es el workspace que se utilizará para el semestre Primavera de EL5206. Para la instalación, clonen este repositorio en su directorio HOME, entren a la carpeta y luego deben hacer `source` al `install.bash`.

    cd ~
    git clone https://github.com/felipe-vergaram/el5206_ws.git
    cd el5206_ws
    source install.bash
